import SwiftUI

struct ContentView: View {
    var body: some View {
        Color.blue.edgesIgnoringSafeArea(.all)
        VStack {
            Text("Hello, world!")
            Text("First App")
        }
    }
}

